﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public const string connectionString = 
                        @"Server=PRETORIAN\SQLEXPRESS;Database=Sales;Integrated Security=true";

    }
}

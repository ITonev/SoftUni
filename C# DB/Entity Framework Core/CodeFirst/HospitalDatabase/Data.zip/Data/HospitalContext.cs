﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace HospitalDatabase.Data
{
   public class HospitalContext : DbContext
    {

    }
}

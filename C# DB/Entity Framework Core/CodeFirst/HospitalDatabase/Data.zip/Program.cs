﻿using System;

namespace HospitalDatabase
{
    public class Program
    {
        public static void Main(string[] args)
        {

        }
    }
}

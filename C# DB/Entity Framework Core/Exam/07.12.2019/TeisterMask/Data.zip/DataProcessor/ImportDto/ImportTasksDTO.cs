﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TeisterMask.DataProcessor.ImportDto
{
    class ImportTasksDTO
    {
        public int MyProperty { get; set; }
    }
}

﻿using System;

namespace Cinema.DataProcessor.ImportDto
{
    internal class XmlTyoeAttribute : Attribute
    {
    }
}